create function addProduct(fname varchar(20), fdesc varchar(255), fprice int, fimagepath varchar(255))
  returns int
  BEGIN
declare newid int;
insert into product(name,description,price,imagepath)value(fname,fdesc,fprice,fimagepath);
select ifnull(max(id),0) into newid from product;
RETURN newid;
END;

