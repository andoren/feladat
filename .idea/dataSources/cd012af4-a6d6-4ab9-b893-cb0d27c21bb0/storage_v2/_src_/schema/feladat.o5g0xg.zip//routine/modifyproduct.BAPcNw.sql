create procedure modifyproduct(IN pname varchar(20), IN pdesc varchar(255), IN pprice int, IN pimagepath varchar(255),
                               IN pid   int)
  BEGIN
update prodcut set name = pname,description = pdesc,price = pprice, imagepath = pimagepath where id = pid;
END;

