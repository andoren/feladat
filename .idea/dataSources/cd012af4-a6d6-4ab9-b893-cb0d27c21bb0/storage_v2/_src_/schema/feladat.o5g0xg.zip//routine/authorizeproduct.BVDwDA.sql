create procedure authorizeproduct(IN productid int)
  BEGIN
update product set isaccapted = 1 where id = productid;
END;

