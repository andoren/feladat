create procedure AddUser(IN pusername varchar(20), IN ppassword varchar(255), IN prealname varchar(50),
                         IN prole     varchar(5), IN pemail varchar(255))
  BEGIN
	insert into user(username,password,realname,role,email)value(pusername,ppassword,prealname,prole,pemail);	
END;

