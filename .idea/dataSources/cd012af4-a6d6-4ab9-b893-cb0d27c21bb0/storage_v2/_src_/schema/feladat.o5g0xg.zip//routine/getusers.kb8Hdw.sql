create procedure getUsers()
  BEGIN
 select  id, username, realname,email from user where role = "user" ;
END;

