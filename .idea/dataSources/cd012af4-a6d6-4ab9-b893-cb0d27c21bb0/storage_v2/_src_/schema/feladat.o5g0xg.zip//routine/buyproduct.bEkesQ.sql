create procedure buyproduct(IN productid int, IN buyerid int)
  BEGIN
update product set issold = 1 , buyer = buyerid, sold_date = current_timestamp() where id = productid;
END;

