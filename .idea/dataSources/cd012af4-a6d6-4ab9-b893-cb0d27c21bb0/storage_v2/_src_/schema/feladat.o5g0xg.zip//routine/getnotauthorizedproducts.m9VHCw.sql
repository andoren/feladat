create procedure getnotauthorizedproducts()
  BEGIN
select * from product where isaccapted = 0;
END;

